
    //Time Picker
    $('#time').datetimepicker({
      datepicker:false,
      format:'H:i',
      step:15
    });
    // Date Picker
    $('#date').datetimepicker({
      timepicker:false,
      format:'d/m/Y',
    });

